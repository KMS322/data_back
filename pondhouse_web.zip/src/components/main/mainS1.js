const MainS1 = () => {
  return (
    <div className="main_s1">
      <div className="text_box">
        서로를 마주보는 시간
        <br /> 순간의 공기, 찰나의 눈빛
        <br />
        <br /> 함께 발 맞추어 내딛은
        <br />첫 걸음
        <br />
        <br />그 날의 감정을 온전히 담아,
        <br />
        <br />
        당신께 전합니다.
      </div>
      <img src="/images/main_s1_img.jpg" alt="" />
    </div>
  );
};

export default MainS1;
