import "../css/adminHeader.css";
const AdminHeader = () => {
  return (
    <div className="adminHeader">
      <img src="/images/logo.png" alt="" />
    </div>
  );
};

export default AdminHeader;
